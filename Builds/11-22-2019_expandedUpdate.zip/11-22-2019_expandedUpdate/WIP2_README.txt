*Controls

WASD to move
Mouse to rotate perspective
E to interact
Arrow Keys to switch perspective (not optimized for this build at the moment)

*Key for Puzzle

There was an error in importing the sprites projected onto the rotating Zodiac disks.

Real Symbol	Error
Bunny		Bunny
Snake		Cat
Pig		Chicken
Rat		Rat
Chicken		Pig
Cat		Snake

Example:
If you want to input a cat into your answer, input snake instead.
