﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class smoothCamera : MonoBehaviour
{
    public Transform target;
    public float speed = 1f; //speed at which camera will move

    int randomTarget; //for numbering available objects in the GetNewTarget() function
    Quaternion newRot;
    Vector3 relPos;

    /*
     * The scene is a camera and two spheres
     * The camera will pick a random sphere and pan to it
     * The camera movement code can easily be repurposed or adjusted as needed for the project
     */

    
    void Update(){
        if (target == null){ //pick a new target, then rotate the camera to view the target object
            GetNewTarget();
        } else{
            relPos = target.position - transform.position;
            newRot = Quaternion.LookRotation(relPos);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, newRot, Time.time * speed);
        }
    }

    //GetNewTarget() finds objects with the tag 'ball' and will randomly pick one 
    void GetNewTarget() {
        GameObject[] possibleTargets;
        possibleTargets = GameObject.FindGameObjectsWithTag("ball");
        if (possibleTargets.Length > 0){
            randomTarget = Random.Range(0, possibleTargets.Length);
            target = possibleTargets[randomTarget].transform;
        }
    }
}
